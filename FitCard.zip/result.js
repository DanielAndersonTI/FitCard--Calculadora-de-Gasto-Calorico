document.addEventListener('DOMContentLoaded', () => {
    // Obter dados do localStorage
    const dados = JSON.parse(localStorage.getItem('resultadoFitcard'));
    
    if (!dados) {
        window.location.href = 'index.html';
        return;
    }
    
    // Atualizar a data atual
    const now = new Date();
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    document.getElementById('current-date').textContent = now.toLocaleDateString('pt-BR', options);
    
    // Preencher os dados no cartão (removendo peso e idade)
    document.getElementById('activity-title').textContent = 
        dados.atividade.charAt(0).toUpperCase() + dados.atividade.slice(1);
    
    document.getElementById('time-value').textContent = 
        `${dados.tempoOriginal} ${dados.unidade}`;
    
    document.getElementById('distance-value').textContent = 
        `${dados.distancia} km`;
    
    // Removidas as linhas que exibiam peso e idade
    document.getElementById('gender-value').textContent = 
        dados.genero.charAt(0).toUpperCase() + dados.genero.slice(1);
    
    document.getElementById('calories-value').textContent = 
        `${dados.calorias} kcal`;
    
    // Atualizar ícone conforme a atividade
    const activityIcon = document.querySelector('.activity-icon svg');
    if (dados.atividade === 'caminhada') {
        activityIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />';
    } else if (dados.atividade === 'corrida') {
        activityIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />';
    } else if (dados.atividade === 'pedal') {
        activityIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z" />';
    }
    
    // Botão para baixar imagem
    document.getElementById('baixarImagem').addEventListener('click', () => {
        html2canvas(document.getElementById('card'), {
            scale: 2,
            useCORS: true,
            scrollX: 0,
            scrollY: 0,
            backgroundColor: null
        }).then(canvas => {
            const link = document.createElement('a');
            link.download = `fitcard_${dados.atividade}_${dados.calorias}kcal.png`;
            link.href = canvas.toDataURL('image/png');
            link.click();
        });
    });
    
    // Botão para novo cálculo
    document.getElementById('novoCalculo').addEventListener('click', () => {
        window.location.href = 'index.html';
    });
});