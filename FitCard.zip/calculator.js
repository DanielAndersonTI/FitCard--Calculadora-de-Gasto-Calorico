document.addEventListener('DOMContentLoaded', () => {
    // Unidades de tempo
    let tempoEmMinutos = true;
    const btnMinutos = document.getElementById('btnMinutos');
    const btnHoras = document.getElementById('btnHoras');

    const marcarBotao = () => {
        if (tempoEmMinutos) {
            btnMinutos.classList.add('active');
            btnHoras.classList.remove('active');
        } else {
            btnHoras.classList.add('active');
            btnMinutos.classList.remove('active');
        }
    };

    // Inicializar botões
    marcarBotao();

    // Event listeners para os botões
    btnMinutos.addEventListener('click', () => { 
        tempoEmMinutos = true; 
        marcarBotao(); 
    });
    
    btnHoras.addEventListener('click', () => { 
        tempoEmMinutos = false; 
        marcarBotao(); 
    });

    // Formulário
    const fitForm = document.getElementById('fitForm');
    fitForm.addEventListener('submit', e => {
        e.preventDefault();
        
        // Obter valores dos campos
        const atividade = document.getElementById('atividade').value;
        const tempoInput = document.getElementById('tempo').value;
        const distanciaInput = document.getElementById('distancia').value;
        const pesoInput = document.getElementById('peso').value;
        const idadeInput = document.getElementById('idade').value;
        const genero = document.getElementById('genero').value;

        // Validar campos
        if (!tempoInput || !distanciaInput || !pesoInput || !idadeInput) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        const tempo = parseFloat(tempoInput);
        const distancia = parseFloat(distanciaInput);
        const peso = parseFloat(pesoInput);
        const idade = parseInt(idadeInput);

        if ([tempo, distancia, peso, idade].some(x => isNaN(x) || x <= 0)) {
            alert("Por favor, preencha todos os campos com valores positivos.");
            return;
        }

        // Converter tempo para minutos se estiver em horas
        const tempoFinal = tempoEmMinutos ? tempo : tempo * 60;
        
        // Valores MET para diferentes atividades
        const metValores = {
            caminhada: 3.8, 
            corrida: 7.5, 
            pedal: 6.8
        };
        
        // Cálculo de calorias: (MET × 3.5 × peso) / 200 × tempo em minutos
        const calorias = ((metValores[atividade] * 3.5 * peso) / 200) * tempoFinal;

        const resultado = {
            atividade,
            tempo: tempoFinal,
            tempoOriginal: tempo,
            unidade: tempoEmMinutos ? "minutos" : "horas",
            distancia: parseFloat(distancia.toFixed(1)),
            peso, 
            idade, 
            genero,
            calorias: Math.round(calorias)
        };

        // Salvar no localStorage e navegar para a página de resultado
        localStorage.setItem('resultadoFitcard', JSON.stringify(resultado));
        window.location.href = 'result.html';
    });

    // Focar no primeiro campo
    document.getElementById('tempo').focus();
});