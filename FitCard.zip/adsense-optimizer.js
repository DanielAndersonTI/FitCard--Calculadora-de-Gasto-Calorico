// Otimizador de AdSense para mobile
class AdSenseOptimizer {
    constructor() {
        this.adSlots = [];
        this.adRefreshInterval = null;
        this.init();
    }
    
    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeAds());
        } else {
            this.initializeAds();
        }
    }
    
    initializeAds() {
        // Aguardar um pouco para carregar o conteúdo primeiro
        setTimeout(() => {
            this.loadAds();
            this.setupAdRefresh();
            this.trackAdPerformance();
        }, 800);
    }
    
    loadAds() {
        if (typeof adsbygoogle !== 'undefined') {
            try {
                adsbygoogle.push({});
                console.log('✅ AdSense carregado com sucesso');
            } catch (error) {
                console.log('⚠️ Erro ao carregar AdSense:', error);
            }
        }
    }
    
    setupAdRefresh() {
        // Recarregar anúncios a cada 45 segundos (otimizado para mobile)
        this.adRefreshInterval = setInterval(() => {
            this.loadAds();
        }, 45000);
        
        // Recarregar após interações do usuário
        this.setupInteractionTracking();
    }
    
    setupInteractionTracking() {
        // Recarregar após cliques importantes
        const importantButtons = [
            'baixarImagem',
            'novoCalculo',
            'btnMinutos',
            'btnHoras'
        ];
        
        importantButtons.forEach(buttonId => {
            const button = document.getElementById(buttonId);
            if (button) {
                button.addEventListener('click', () => {
                    setTimeout(() => this.loadAds(), 1500);
                });
            }
        });
        
        // Recarregar quando o usuário voltar para a página
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                setTimeout(() => this.loadAds(), 1000);
            }
        });
    }
    
    trackAdPerformance() {
        // Track cliques nos anúncios (se Google Analytics estiver instalado)
        const adContainers = document.querySelectorAll('.ad-container');
        adContainers.forEach((container, index) => {
            container.addEventListener('click', () => {
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'ad_click', {
                        'event_category': 'adsense',
                        'event_label': `ad_position_${index + 1}`,
                        'value': 1
                    });
                }
            });
        });
        
        // Track impressões de anúncios
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const adContainer = entry.target;
                    console.log('📊 Anúncio visível:', adContainer);
                }
            });
        }, { threshold: 0.5 });
        
        adContainers.forEach(container => {
            observer.observe(container);
        });
    }
    
    // Método para carregar anúncios específicos
    loadSpecificAd(slotId) {
        if (typeof adsbygoogle !== 'undefined') {
            const adElement = document.querySelector(`[data-ad-slot="${slotId}"]`);
            if (adElement) {
                adsbygoogle.push({});
            }
        }
    }
    
    // Destruir otimizador (para SPA)
    destroy() {
        if (this.adRefreshInterval) {
            clearInterval(this.adRefreshInterval);
        }
    }
}

// Inicializar otimizador automaticamente
let adsenseOptimizer = null;

function initializeAdSense() {
    if (!adsenseOptimizer) {
        adsenseOptimizer = new AdSenseOptimizer();
    }
}

// Inicializar quando o script carregar
initializeAdSense();

// Prevenir zoom duplo-tap em mobile
let lastTouchEnd = 0;
document.addEventListener('touchend', function (event) {
    const now = Date.now();
    if (now - lastTouchEnd <= 300) {
        event.preventDefault();
    }
    lastTouchEnd = now;
}, false);

// Otimizar performance em mobile
if ('connection' in navigator) {
    const connection = navigator.connection;
    if (connection) {
        if (connection.saveData) {
            // Modo economia de dados - carregar menos anúncios
            console.log('📱 Modo economia de dados ativado');
        }
        
        if (connection.effectiveType) {
            console.log('🌐 Tipo de conexão:', connection.effectiveType);
        }
    }
}